package com.example.campus_bites_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link CanteenFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class CanteenFragment extends Fragment {
    private RecyclerView foodRecyclerView;
    private FoodAdapter foodAdapter;
    private List<FoodItem> foodItems;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    FirebaseDatabase database;
    DatabaseReference Category;
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;


    public CanteenFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment CanteenFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static CanteenFragment newInstance(String param1, String param2) {
        CanteenFragment fragment = new CanteenFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_canteen, container, false);
        foodRecyclerView = view.findViewById(R.id.foodRecyclerView);

        // Create a list of food items
        foodItems = new ArrayList<>();
        foodItems.add(new FoodItem("Masala Dosa", "45", R.drawable.masaladosa));
        foodItems.add(new FoodItem("SouthThali", "80", R.drawable.southindianthali));

        foodItems.add(new FoodItem("NorthThali", "80", R.drawable.northindianthali));
        foodItems.add(new FoodItem("Chole Bature", "30", R.drawable.cholebature));
        foodItems.add(new FoodItem("Curd Rice", "20", R.drawable.curdrice));
        foodItems.add(new FoodItem("French Fries", "40", R.drawable.frenchfries));
        foodItems.add(new FoodItem("Fried Rice", "50", R.drawable.friedrice));
        foodItems.add(new FoodItem("Lemon Rice", "50", R.drawable.lemonrice));

        foodItems.add(new FoodItem("Gobhi", "40", R.drawable.gobhimanchurian));
        foodItems.add(new FoodItem("Golgappa", "30", R.drawable.golgappa));
        foodItems.add(new FoodItem("Idly", "30", R.drawable.idli));
        foodItems.add(new FoodItem("Masala Poori", "30", R.drawable.masalapoori));
        foodItems.add(new FoodItem("Noodles", "30", R.drawable.noodles));
        foodItems.add(new FoodItem("Paratha", "30", R.drawable.paratha));
        foodItems.add(new FoodItem("Salad", "30", R.drawable.salad));

        foodItems.add(new FoodItem("Millets Upma", "30", R.drawable.millets));


        // Create and set the adapter for the RecyclerView
        foodAdapter = new FoodAdapter(getActivity(), foodItems);
        foodRecyclerView.setAdapter(foodAdapter);
        foodRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return view;
    }
}