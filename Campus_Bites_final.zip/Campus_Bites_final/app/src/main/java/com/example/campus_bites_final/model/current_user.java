package com.example.campus_bites_final.model;

public class current_user {
    public static User currentuser;
    private static String currname;

    public current_user() {
    }

    public static User getCurrentuser() {
        return currentuser;
    }

    public static void setCurrentuser(User user) {
        currentuser = user;
        currname = user.getName();
    }

    public static String getCurrname() {
        return currname;
    }
}

