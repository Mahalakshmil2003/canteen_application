package com.example.campus_bites_final;

public class FoodItem {
        private String name;
        private String price;
        private int imageResId;

        public FoodItem(String name, String price, int imageResId) {
            this.name = name;
            this.price = price;
            this.imageResId = imageResId;
        }
    public FoodItem(String name) {
        this.name = name;
    }

        public String getName() {
            return name;
        }

        public String getPrice() {
            return price;
        }

        public int getImageResId() {
            return imageResId;
        }
}


