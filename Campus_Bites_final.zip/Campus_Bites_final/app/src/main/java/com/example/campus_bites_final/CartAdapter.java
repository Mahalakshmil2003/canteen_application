package com.example.campus_bites_final;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {

    private Context context;
    private List<CartItem> cartItems;
    private OnRemoveItemClickListener removeItemClickListener;

    public CartAdapter(Context context, List<CartItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
    }

    public void setOnRemoveItemClickListener(OnRemoveItemClickListener listener) {
        this.removeItemClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_cart_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CartItem cartItem = cartItems.get(position);

        holder.cartItemName.setText(cartItem.getFood_name());
        holder.cartItemPrice.setText(String.valueOf(cartItem.getPrice()));
        holder.cartItemQuantity.setText(String.valueOf(cartItem.getQuantity()));

        holder.removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int clickedPosition = holder.getAdapterPosition();
                if (removeItemClickListener != null && clickedPosition != RecyclerView.NO_POSITION) {
                    removeItemClickListener.onRemoveItemClick(clickedPosition);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        if (cartItems != null) {
            return cartItems.size();
        } else {
            return 0;
        }
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView cartItemName;
        TextView cartItemPrice;
        TextView cartItemQuantity;
        Button removeButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cartItemName = itemView.findViewById(R.id.cartName);
            cartItemPrice = itemView.findViewById(R.id.cartPrice);
            cartItemQuantity = itemView.findViewById(R.id.cartQuantity);
            removeButton = itemView.findViewById(R.id.deleteButton);
        }
    }

    public interface OnRemoveItemClickListener {
        void onRemoveItemClick(int position);
    }
}
