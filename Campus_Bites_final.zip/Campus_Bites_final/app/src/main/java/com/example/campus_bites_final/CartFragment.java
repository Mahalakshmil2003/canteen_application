package com.example.campus_bites_final;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campus_bites_final.model.current_user;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class CartFragment extends Fragment implements CartAdapter.OnRemoveItemClickListener {

    private RecyclerView recyclerView;
    private CartAdapter cartAdapter;
    private List<CartItem> cartItems;

    Button total;

    public CartFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_cart, container, false);

        total=view.findViewById(R.id.totalbutton);
        total.setEnabled(false);
        recyclerView = view.findViewById(R.id.cartRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        cartItems = new ArrayList<>();

        // Initialize Firebase
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference cartRef = database.getReference("Cart").child(current_user.getCurrentuser().getPhone());

        cartRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                cartItems.clear(); // Clear the previous cart items

                int totalBill = 0;

                for (DataSnapshot cartSnapshot : snapshot.getChildren()) {
                    CartItem cartItem = cartSnapshot.getValue(CartItem.class);
                    cartItems.add(cartItem);

                    // Calculate the total bill by adding the price of each item
                    totalBill += cartItem.getPrice() ;
                }

                // Update the cartAdapter with the new cartItems
                cartAdapter.notifyDataSetChanged();

                // Set the total bill on the "Total Rs" button
                Button totalButton = view.findViewById(R.id.totalbutton);
                totalButton.setText("Total Rs: " + totalBill);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                // Handle database error
            }
        });

        cartAdapter = new CartAdapter(getActivity(), cartItems);
        recyclerView.setAdapter(cartAdapter);

        cartAdapter.setOnRemoveItemClickListener(this);

        return view;
    }

    @Override
    public void onRemoveItemClick(int position) {
        if (position >= 0 && position < cartItems.size()) {
            CartItem removedItem = cartItems.get(position);

            // Remove the item from the Firebase database using its itemId
            final FirebaseDatabase database = FirebaseDatabase.getInstance();
            final DatabaseReference cartRef = database.getReference("Cart").child(current_user.getCurrentuser().getPhone());
            String newn= removedItem.getKey();
            cartRef.child(newn).removeValue();

            cartRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {


                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
            // Remove the item from the cartItems list
            cartItems.remove(position);
            cartAdapter.notifyItemRemoved(position);
        }
    }
}


