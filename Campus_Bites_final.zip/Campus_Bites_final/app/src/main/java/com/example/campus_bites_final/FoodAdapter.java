package com.example.campus_bites_final;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.campus_bites_final.model.Cart;
import com.example.campus_bites_final.model.current_user;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.UUID;

public class FoodAdapter extends RecyclerView.Adapter<FoodAdapter.ViewHolder> {

    private Context context;
    private List<FoodItem> foodItems;
    private OnAddToCartClickListener addToCartClickListener;

    public FoodAdapter(Context context, List<FoodItem> foodItems) {
        this.context = context;
        this.foodItems = foodItems;
    }

    public void setOnAddToCartClickListener(OnAddToCartClickListener listener) {
        this.addToCartClickListener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_food, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FoodItem foodItem = foodItems.get(position);

        holder.orderName.setText(foodItem.getName());
        holder.orderPrice.setText(foodItem.getPrice());
        holder.imageView.setImageResource(foodItem.getImageResId());

        // Set click listeners for increment and decrement buttons
        holder.increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(holder.quantityTextView.getText().toString());
                quantity++;
                holder.quantityTextView.setText(String.valueOf(quantity));
            }
        });

        holder.decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(holder.quantityTextView.getText().toString());
                if (quantity > 0) {
                    quantity--;
                    holder.quantityTextView.setText(String.valueOf(quantity));
                }
            }
        });
        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_cart= database.getReference("Cart");

        holder.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int quantity = Integer.parseInt(holder.quantityTextView.getText().toString());
                int price = Integer.parseInt(holder.orderPrice.getText().toString());
                if (quantity > 0) {
                    table_cart.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            String randomKey = UUID.randomUUID().toString();
                            Cart cart = new Cart(randomKey,current_user.getCurrentuser().getPhone(), foodItem.getName(), price*quantity, quantity);
                            table_cart.child(cart.getPhone()).child(randomKey).setValue(cart);

                            Toast.makeText(context, "Item added to cart", Toast.LENGTH_SHORT).show();

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            // Handle onCancelled event
                        }
                    });

                } else {
                    Toast.makeText(context, "Insufficient Quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });


        // Set any other data or event listeners for the food item here
    }

    @Override
    public int getItemCount() {
        return foodItems.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView orderName;
        TextView orderPrice;
        Button increaseButton;
        Button decreaseButton;
        TextView quantityTextView;
        Button addButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imageView);
            orderName = itemView.findViewById(R.id.orderName);
            orderPrice = itemView.findViewById(R.id.orderPrice);
            increaseButton = itemView.findViewById(R.id.increaseButton);
            decreaseButton = itemView.findViewById(R.id.decreaseButton);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            addButton = itemView.findViewById(R.id.addbutton);
        }
    }

    public interface OnAddToCartClickListener {
        void onAddToCartClick(String name, int quantity, int price);
    }
}


