package com.example.campus_bites_final;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.campus_bites_final.model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignUp extends AppCompatActivity {

    EditText txtname, txtphone, txtpassword;
    Button signupbtn;
    FirebaseAuth myauth;
    TextView signin2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE); //will hide the title
        getSupportActionBar().hide(); // hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_sign_up);

        myauth = FirebaseAuth.getInstance();
        txtname = findViewById(R.id.name);
        txtphone = findViewById(R.id.phone);
        txtpassword = findViewById(R.id.password);
        signupbtn = findViewById(R.id.signupbtn);
        signin2=findViewById(R.id.signin2);

        final FirebaseDatabase database = FirebaseDatabase.getInstance();
        final DatabaseReference table_user = database.getReference("User");

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProgressDialog myDialog = new ProgressDialog(SignUp.this);
                myDialog.setMessage("Please wait...");
                myDialog.show();

                table_user.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if (snapshot.child(txtphone.getText().toString()).exists()) {
                            myDialog.dismiss();

                            Toast.makeText(SignUp.this, "Phone Number Already exists", Toast.LENGTH_SHORT).show();
                        } else {
                            myDialog.dismiss();
                            User user = new User(txtname.getText().toString(), txtpassword.getText().toString(),txtphone.getText().toString());
                            table_user.child(txtphone.getText().toString()).setValue(user);
                            Toast.makeText(SignUp.this, "Signup successful", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        myDialog.dismiss();
                        Toast.makeText(SignUp.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        signin2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SignUp.this, SignIn.class);
                startActivity(intent);
            }
        });
    }
}
