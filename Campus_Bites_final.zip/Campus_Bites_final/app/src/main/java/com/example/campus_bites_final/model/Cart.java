package com.example.campus_bites_final.model;

public class Cart{
    private String Key;
    private String Phone;
    private String Food_name;
    private int Price;
    private int Quantity;

    public Cart(){

    }

    public Cart(String key, String phone, String food_name, int price, int quantity) {
        Key = key;
        Phone = phone;
        Food_name = food_name;
        Price = price;
        Quantity = quantity;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String phone) {
        Phone = phone;
    }

    public String getFood_name() {
        return Food_name;
    }

    public void setFood_name(String food_name) {
        Food_name = food_name;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int quantity) {
        Quantity = quantity;
    }


    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }
}
