package com.example.campus_bites_final;

public class CartItem {
    private String Food_name;
    private int price;
    private int quantity;
    private String Key; // Add an item ID field


    public CartItem(String food_name, int price, int quantity, String Key) {
        Food_name = food_name;
        this.price = price;
        this.quantity = quantity;
        this.Key = Key;
    }

    public CartItem() {
    }

    // Getters and setters for name, price, and quantity


    public String getFood_name() {
        return Food_name;
    }

    public void setFood_name(String food_name) {
        Food_name = food_name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getKey() {
        return Key;
    }

    public void setKey(String key) {
        Key = key;
    }
}

