package com.example.campus_bites_final;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ViewOrders extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_orders);
    }
}